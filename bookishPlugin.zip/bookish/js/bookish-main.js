jQuery(function($){
hoverShowMetas();
	$(document).on("click", ".cat-list_item.active",function(e) {
		  e.preventDefault();
	});
	$(document).on("click", ".cat-list_item:not('.active')",function(e) {
	  e.preventDefault();
		 var cat = $(this).data('slug'); 
		 var tot = $(this).data('postcount');
		var mainDataPerPage = $(".bookish-filter-button-wrap").attr('data-perpage');
		$(this).attr('data-thispage',mainDataPerPage);
		var updatedDataThisPage = $(this).attr('data-thispage');
		console.log(tot);
		console.log(updatedDataThisPage);
		if(tot <= updatedDataThisPage){
		   $(".bookish-load-more").remove();
		   }else {
			  if($('.bookish-load-more').length == 0){
		   			$('<div class="bookish-load-more">Load More</div>').insertAfter('.bookish-posts');
		   		}
		   }
		
  $('.cat-list_item').removeClass('active');	
  $(this).addClass('active');
		$.ajax({
    type: 'POST',
    url: '/wp-admin/admin-ajax.php',
    dataType: 'html',
    data: {
      action: 'filter_books',
      category: $(this).data('slug'),
		postCount: $(this).data('postcount'),
		perpage: $(".bookish-filter-button-wrap").attr('data-perpage'),
    },
    success: function(res) {
      $('.bookish-posts').html(res);
		$('.active').attr('data-paged',1);
		$('.active').attr('data-thispage',$(".bookish-filter-button-wrap").attr('data-perpage'));
		hoverShowMetas();
		}
  });
});
	
	$(document).on("click", ".bookish-load-more",function()
	{
		var thisPage =  $('.active').attr('data-paged');
		var thisCat =  $('.active').data('slug');
		var TotPostCategory =  $('.active').data('postcount');
		var perpageN = $(".bookish-filter-button-wrap").data('perpage');
		thisPage++;		
		loadMoreAjax(thisPage, thisCat, TotPostCategory, perpageN);
	});
	
	
	
	
		function hoverShowMetas(){
			$( ".bookish-hover-items.overlay" ).hover(function() {
		  $( this ).fadeTo( "fast", 1 );
		}, function() {
		  $( this ).fadeTo( "fast", 0 );
		});
	}	
	
	function loadMoreAjax( pageNew , thiscat, totalPost ,perpage){
	
		    $.ajax({
				type: 'POST',
				url: '/wp-admin/admin-ajax.php',
				dataType: 'html',
				data: {
				  action: 'your_load_more',
				  count: $(".bookish-post").length,
					newPage : pageNew,
					categoryN: thiscat,
					perpageNew : perpage,
				},
				success: function(res) {
					$('.bookish-posts').append(res);
					var dataThisPage = $(".bookish-post").length;
					if(totalPost <= dataThisPage){
					   $(".bookish-load-more").remove();
					   }
					$('.active').attr('data-paged',pageNew);
					$('.active').attr('data-thispage',dataThisPage);
					hoverShowMetas();
					
				}
			});
		
	}		
	
}); 

