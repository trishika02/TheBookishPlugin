jQuery(document).ready( function($){
	
	var mediaUploader;
	var attachments;
	var imageUrls ='';
	if($('#gallery_pictures').val()){
	imageUrls += $('#gallery_pictures').val();
	}
 $(document).on('click', '#upload-button', function(e)  {
		e.preventDefault();
		if( mediaUploader ){
			mediaUploader.open();
			return;
		}
		
		mediaUploader = wp.media.frames.file_frame = wp.media({
			title: 'Choose Images For Book Gallery',
			button: {
				text: 'Choose Images'
			},
			multiple: 'add'
		});
		
		mediaUploader.on('select', function(){
			attachments = mediaUploader.state().get('selection').toJSON();
			var i;
			for (i = 0; i < attachments.length; i++) {
				var urlsingle =  attachments[i].url;
				 imageUrls += urlsingle+'|';
				$('.gallery-preview').append('<div class="gallery-img-wrap" id="gallery-wrap-'+i+'"><img height="100%" width="auto" id="gallery-'+i+'" class="galley-preview-single" src="'+urlsingle+'"/><div class="cross-remove dashicons dashicons-dismiss" id="'+i+'"></div></div>');
			}
			$('#gallery_pictures').val(imageUrls);
			console.log(imageUrls)
		});
		
		mediaUploader.open();
			
	});
	var galleryFieldValue = $('#gallery_pictures').val();
	
	$(document).on('click', '.cross-remove', function()  {
		var theId = $(this).attr('id');
		var imageSrc = ($(this).siblings('img.galley-preview-single').attr("src"))+'|';
		imageUrls = imageUrls.replace(imageSrc, '');
		$('#gallery_pictures').val(imageUrls);
		$(this).closest('.gallery-img-wrap').remove();
		
	});
	
	
	
	
	
	
	
});