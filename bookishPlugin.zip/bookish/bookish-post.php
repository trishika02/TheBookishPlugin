<?php
/*
Plugin Name: Bookish Post Plugin
Description: A Plugin for Book post Gallery
Version:     1.0.0
Author:      Trina Haque
Author URI:  https://trinahaque.wordpress.com/
*/
if( !defined('ABSPATH') ){
	exit;
}

require_once ( plugin_dir_path(__FILE__) . 'bookish-custom-post-type.php' );
require_once ( plugin_dir_path(__FILE__) . 'bookish-metabox.php' );
require_once ( plugin_dir_path(__FILE__) . 'bookish-post-template.php' );



function tris_admin_enqueue_scripts() {
	global $pagenow, $typenow;

	if ( $typenow == 'trisbookish') {

		wp_enqueue_style( 'bookish-admin-css', plugins_url( 'css/admin.css', __FILE__ ) );

	}

	if ( ($pagenow == 'post.php' || $pagenow == 'post-new.php') && $typenow == 'trisbookish' ) {
		wp_enqueue_media();
		wp_enqueue_script( 'bookish-admin-js', plugins_url( 'js/admin-js.js', __FILE__ ), array(), true );
		

	}


}
add_action( 'admin_enqueue_scripts', 'tris_admin_enqueue_scripts' );

function tris_enqueue_scripts() {
	wp_enqueue_style( 'tris-style', plugins_url( 'css/bookish-style.css', __FILE__ ), array(), '3.0.3' );
	wp_enqueue_style( 'abel-font', 'https://fonts.googleapis.com/css2?family=Abel&display=swap', array(), '3.0.3' );
	
	wp_enqueue_script( 'jquery-min-js', 'https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js', array(), true );
	wp_enqueue_script( 'bookish-main-js', plugins_url( 'js/bookish-main.js', __FILE__ ), array(), true );
}
add_action( 'wp_enqueue_scripts', 'tris_enqueue_scripts' );
