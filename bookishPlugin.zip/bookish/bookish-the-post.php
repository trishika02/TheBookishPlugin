<div class="bookish-post" style="background-image: url(<?php the_post_thumbnail_url(); ?>);">
					<div class="bookish-hover-items overlay" style="opacity: 0;">
						<div class="bookish-meta-wrap">
							<div class="bookish-post-title"><?php the_title(); ?></div>
							<div class="bookish-post-excerpt"><p><?php the_excerpt(); ?></p></div>
							<div class="bookish-post-more-link"><a src="<?php the_permalink() ?>" class="read-more-link">Read More</a></div>
						</div>
					</div>
</div>
				