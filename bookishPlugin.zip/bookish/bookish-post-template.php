<?php
global $post;
add_shortcode( 'books', 'bookish_post_parameters_shortcode' );
function bookish_post_parameters_shortcode( $atts ) {
    ob_start();
    
    extract( shortcode_atts( array (
        'per_page' => -1,
    ), $atts ) );
    $options = array(
        'post_type' => 'trisbookish',
        'order' => 'DESC',
        'orderby' => 'date',
        'posts_per_page' => $per_page,
    );
    $query = new WP_Query( $options );
    $categoryTerms = get_terms('book_category');
	$count_posts = wp_count_posts( 'trisbookish' )->publish;
	$i = 0;
	?>

<div class="bookish-wrap-gallery">
	<div class="bookish-filter-buttons">
		  <ul class="bookish-filter-button-wrap" data-category="all" data-perpage="<?php echo $per_page; ?>">
			  	<li class="bookish-filter-list term_id_all">
				<a class="cat-list_item active" href="#" data-paged="1" data-postcount="<?php echo $count_posts; ?>" data-thispage="5" data-slug="all" data-type="trisbookish">
					All
				</a>
				</li>
			  <?php
			  foreach($categoryTerms as $singleTerm ){
				  ?>
			<li class="bookish-filter-list term_id_<?php echo $i; ?>">
				<a class="cat-list_item" href="#" data-paged="1" data-postcount="<?php echo $singleTerm->count; ?>" data-slug="<?php echo $singleTerm->slug; ?>" data-type="trisbookish" data-thispage="<?php echo $per_page; ?>"><?php echo $singleTerm->name; ?></a>
			</li>  
			  <?php
				  $i++;
			  }
			  ?>
		</ul>
	</div>
<div class="bookish-posts">
	<?php
	
	
	  if ( $query->have_posts() ) { 
    		while ( $query->have_posts() ) { 
				 $query->the_post();
				
				include('bookish-the-post.php');
			
			}
	  }
	?>
	</div>
	<div class="bookish-load-more">Load More</div>
</div>
<?php
wp_reset_postdata();
}
?>
