<?php
function tris_add_custom_meta() {
    add_meta_box(
      'tris_meta',
      __('Book Gallery'),
      'tris_meta_callback',
      'trisbookish',
      'normal',
      'high'
    );
}

add_action( 'add_meta_boxes', 'tris_add_custom_meta' );

function tris_meta_callback( $post ) {
	wp_nonce_field( basename( __FILE__ ), 'tris_bookish_nonce' );
	$tris_stored_meta = get_post_meta( $post->ID );
	 $postmeta = maybe_unserialize( get_post_meta( $post->ID, 'gallery_pictures', true ) );
?>
	<div class="meta-row">	
		<input type="button" class="button button-secondary" value="Upload Book Images" id="upload-button">
		<input type="hidden" id="gallery_pictures" name="gallery_pictures" value="<?php if ( ! empty ( $tris_stored_meta['gallery_pictures'] ) ) { echo esc_attr( $tris_stored_meta['gallery_pictures'][0] );} ?>"/>
		<div class="gallery-preview">
			<?php 
			if ( ! empty ( $tris_stored_meta['gallery_pictures'] ) ) { 
	 			$gallery =  esc_attr( $tris_stored_meta['gallery_pictures'][0]);
	 				$myArray = explode('|', $gallery);
				
					$length = count($myArray);
						for ($i = 0; $i < $length-1; $i++) {
							 ?>
			<div class="gallery-img-wrap" id="gallery-wrap-<?php echo $i;?>">
				<img height="100%" width="auto" id="gallery-<?php echo $i; ?>" class="galley-preview-single" src="<?php echo $myArray[$i]; ?>">
				<div class="cross-remove dashicons dashicons-dismiss" id="<?php echo $i; ?>"></div>
			</div>
							<?php
							
							}
	 				}
			?>
		</div>
	</div>
<?php
}

function tris_meta_save( $post_id ) {
	// Checks save status
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'tris_bookish_nonce' ] ) && wp_verify_nonce( $_POST[ 'tris_bookish_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }
	
	
	if ( isset( $_POST[ 'gallery_pictures' ] ) ) {
    	update_post_meta( $post_id, 'gallery_pictures', sanitize_text_field( $_POST[ 'gallery_pictures' ] ) );
    }
}

add_action( 'save_post', 'tris_meta_save' );










